---
description: Use this command for documentation work and knowledge sync when you need to assemble a first-pass implementation plan or artifact.
---

# Docs Build

Use this command to assemble a first-pass implementation plan or artifact.

Follow this pattern:
1. Confirm the task focus and constraints.
2. Inspect the most relevant files or conversation state.
3. Execute the smallest coherent step that moves the task forward.
4. Return the result clearly, with risks or follow-ups when needed.
