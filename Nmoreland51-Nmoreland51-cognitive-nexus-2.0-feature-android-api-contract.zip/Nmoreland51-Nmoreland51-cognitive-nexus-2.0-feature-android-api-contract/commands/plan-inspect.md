---
description: Use this command for planning and task breakdown when you need to read the relevant code or files before acting.
---

# Plan Inspect

Use this command to read the relevant code or files before acting.

Follow this pattern:
1. Confirm the task focus and constraints.
2. Inspect the most relevant files or conversation state.
3. Execute the smallest coherent step that moves the task forward.
4. Return the result clearly, with risks or follow-ups when needed.
