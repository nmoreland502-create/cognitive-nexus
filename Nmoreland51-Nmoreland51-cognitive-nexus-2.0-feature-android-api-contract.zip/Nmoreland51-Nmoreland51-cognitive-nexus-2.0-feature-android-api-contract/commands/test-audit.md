---
description: Use this command for test creation and validation when you need to inspect the current state and surface the biggest issues.
---

# Test Audit

Use this command to inspect the current state and surface the biggest issues.

Follow this pattern:
1. Confirm the task focus and constraints.
2. Inspect the most relevant files or conversation state.
3. Execute the smallest coherent step that moves the task forward.
4. Return the result clearly, with risks or follow-ups when needed.
