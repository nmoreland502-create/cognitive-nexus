---
name: backend-design
description: Use when work involves backend services, APIs, and business logic and you need to design a stronger structure or approach.
---

# Backend Design

Use this skill when the task is primarily about backend services, APIs, and business logic.

Core workflow:
1. Identify the concrete goal, constraints, and success criteria.
2. Inspect the current state before proposing changes.
3. Design a stronger structure or approach.
4. Prefer the smallest change that improves clarity, safety, or reliability.
5. Summarize the outcome and any follow-up validation that still matters.
