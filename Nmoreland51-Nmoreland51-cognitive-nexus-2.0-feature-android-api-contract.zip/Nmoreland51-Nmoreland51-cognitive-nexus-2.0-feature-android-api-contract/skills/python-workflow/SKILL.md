---
name: python-workflow
description: Use when work involves Python implementation patterns, tooling, and code quality and you need to shape a repeatable workflow for the area.
---

# Python Workflow

Use this skill when the task is primarily about Python implementation patterns, tooling, and code quality.

Core workflow:
1. Identify the concrete goal, constraints, and success criteria.
2. Inspect the current state before proposing changes.
3. Shape a repeatable workflow for the area.
4. Prefer the smallest change that improves clarity, safety, or reliability.
5. Summarize the outcome and any follow-up validation that still matters.
