---
name: security-guide
description: Use when work involves security analysis, hardening, and safe defaults and you need to provide a practical guide for approaching the work.
---

# Security Guide

Use this skill when the task is primarily about security analysis, hardening, and safe defaults.

Core workflow:
1. Identify the concrete goal, constraints, and success criteria.
2. Inspect the current state before proposing changes.
3. Provide a practical guide for approaching the work.
4. Prefer the smallest change that improves clarity, safety, or reliability.
5. Summarize the outcome and any follow-up validation that still matters.
