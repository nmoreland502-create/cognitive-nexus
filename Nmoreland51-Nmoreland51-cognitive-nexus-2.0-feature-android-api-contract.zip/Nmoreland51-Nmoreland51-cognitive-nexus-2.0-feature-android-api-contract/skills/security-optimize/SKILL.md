---
name: security-optimize
description: Use when work involves security analysis, hardening, and safe defaults and you need to optimize the area without losing reliability.
---

# Security Optimize

Use this skill when the task is primarily about security analysis, hardening, and safe defaults.

Core workflow:
1. Identify the concrete goal, constraints, and success criteria.
2. Inspect the current state before proposing changes.
3. Optimize the area without losing reliability.
4. Prefer the smallest change that improves clarity, safety, or reliability.
5. Summarize the outcome and any follow-up validation that still matters.
